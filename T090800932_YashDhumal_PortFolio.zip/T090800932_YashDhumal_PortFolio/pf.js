<script src="https://unpkg.com/typed.js@2.1.0/dist/typed.umd.js"></script>
<script>
    var typed = new Typed('#element', {
        strings: ['Web Developer', 'Graphic Designer', 'Game Designer'],
        typeSpeed: 50,
    });
</script>